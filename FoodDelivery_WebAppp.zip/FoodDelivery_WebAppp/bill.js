    // Retrieve selected items from localStorage
    const selectedItems = JSON.parse(localStorage.getItem("cartItems")) || [];

    // Display the selected items
    const orderSummaryDiv = document.getElementById('order-summary');
    if (selectedItems.length > 0) {
        let itemListHTML = "<ul>";
        selectedItems.forEach(item => {
            itemListHTML += `<li>${item.name} - ${item.price}</li>`;
        });
        itemListHTML += "</ul>";
        orderSummaryDiv.innerHTML = itemListHTML;
    } else {
        orderSummaryDiv.innerHTML = "<p>No items selected.</p>";
    }
