// // // // // Function to update the bill when an item is selected/deselected
// // // function updateBill() {
// // //   const selectedItems = [];
// // //   let total = 0;
  
// // //   // Loop through all checkboxes and get selected items
// // //   const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
// // //   checkboxes.forEach(checkbox => {
// // //       if (checkbox.checked) {
// // //           const itemName = checkbox.nextElementSibling.innerText.split(' - ')[0]; // Extract item name
// // //           const itemPrice = parseFloat(checkbox.dataset.price); // Get item price
// // //           selectedItems.push({ name: itemName, price: itemPrice });
// // //           total += itemPrice; // Update total
// // //       }
// // //   });

// // //   // Save selected items in localStorage
// // //   localStorage.setItem("cartItems", JSON.stringify(selectedItems));

// // //   // Display selected items and total in the bill section
// // //   displayBill(selectedItems, total);
// // // }

// // // // Function to display the selected items and total
// // // function displayBill(selectedItems, total) {
// // //   const selectedItemsDiv = document.getElementById('selectedItems');
// // //   const totalSpan = document.getElementById('total');
  
// // //   if (selectedItems.length > 0) {
// // //       let itemsHTML = "<ul>";
// // //       selectedItems.forEach(item => {
// // //           itemsHTML += `<li>${item.name} - $${item.price}</li>`;
// // //       });
// // //       itemsHTML += "</ul>";
// // //       selectedItemsDiv.innerHTML = itemsHTML;
// // //   } else {
// // //       selectedItemsDiv.innerHTML = "<p>No items selected.</p>";
// // //   }

// // //   // Update total price
// // //   totalSpan.innerText = total.toFixed(2);
// // // }

// // // // Function to clear the selection
// // // function clearSelection() {
// // //   const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
// // //   checkboxes.forEach(checkbox => checkbox.checked = false); // Uncheck all checkboxes
// // //   localStorage.removeItem("cartItems"); // Remove items from localStorage
// // //   updateBill(); // Update the bill to reflect no selected items
// // // }

// // // // Function to handle checkout (this is just a placeholder function)
// // // function checkout() {
// // //   alert("Checkout is not implemented yet.");
// // // }
// // // Function to update the bill when an item is selected/deselected
// // function updateBill() {
// //   const selectedItems = [];
// //   let total = 0;
  
// //   // Loop through all checkboxes and get selected items
// //   const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
// //   checkboxes.forEach(checkbox => {
// //       if (checkbox.checked) {
// //           const itemName = checkbox.nextElementSibling.innerText.split(' - ')[0]; // Extract item name
// //           const itemPrice = parseFloat(checkbox.dataset.price); // Get item price
// //           selectedItems.push({ name: itemName, price: itemPrice });
// //           total += itemPrice; // Update total
// //       }
// //   });

// //   console.log('Selected Items:', selectedItems);  // Debugging line
// //   console.log('Total Price:', total);  // Debugging line

// //   // Save selected items in localStorage
// //   localStorage.setItem("cartItems", JSON.stringify(selectedItems));

// //   // Display selected items and total in the bill section
// //   displayBill(selectedItems, total);
// // }

// // // Function to display the selected items and total
// // function displayBill(selectedItems, total) {
// //   const selectedItemsDiv = document.getElementById('selectedItems');
// //   const totalSpan = document.getElementById('total');
  
// //   if (selectedItems.length > 0) {
// //       let itemsHTML = "<ul>";
// //       selectedItems.forEach(item => {
// //           itemsHTML += `<li>${item.name} - $${item.price}</li>`;
// //       });
// //       itemsHTML += "</ul>";
// //       selectedItemsDiv.innerHTML = itemsHTML;
// //   } else {
// //       selectedItemsDiv.innerHTML = "<p>No items selected.</p>";
// //   }

// //   // Update total price
// //   totalSpan.innerText = total.toFixed(2);
// // }

// // // Function to clear the selection
// // function clearSelection() {
// //   const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
// //   checkboxes.forEach(checkbox => checkbox.checked = false); // Uncheck all checkboxes
// //   localStorage.removeItem("cartItems"); // Remove items from localStorage
// //   updateBill(); // Update the bill to reflect no selected items
// // }

// // // Function to handle checkout (this is just a placeholder function)
// // function checkout() {
// //   alert("Checkout is not implemented yet.");
// // }

// // // Load items from localStorage when the page loads
// // document.addEventListener("DOMContentLoaded", () => {
// //   const savedItems = JSON.parse(localStorage.getItem("cartItems")) || [];
// //   displayBill(savedItems, savedItems.reduce((acc, item) => acc + item.price, 0));
// // });
// // Function to update the bill when an item is selected/deselected
// function updateBill() {
//   const selectedItems = [];
//   let total = 0;
  
//   // Loop through all checkboxes and get selected items
//   const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
//   checkboxes.forEach(checkbox => {
//       if (checkbox.checked) {
//           const itemName = checkbox.nextElementSibling.innerText.split(' - ')[0]; // Extract item name
//           const itemPrice = parseFloat(checkbox.dataset.price); // Get item price
//           selectedItems.push({ name: itemName, price: itemPrice });
//           total += itemPrice; // Update total
//       }
//   });

//   // Debugging log to check if selected items are being collected correctly
//   console.log('Selected Items:', selectedItems);  // Debugging line
//   console.log('Total Price:', total);  // Debugging line

//   // Save selected items in localStorage
//   localStorage.setItem("cartItems", JSON.stringify(selectedItems));

//   // Display selected items and total in the bill section
//   displayBill(selectedItems, total);
// }

// // Function to display the selected items and total
// function displayBill(selectedItems, total) {
//   const selectedItemsDiv = document.getElementById('selectedItems');
//   const totalSpan = document.getElementById('total');
  
//   // Check if there are any selected items
//   if (selectedItems.length > 0) {
//       let itemsHTML = "<ul>";
//       selectedItems.forEach(item => {
//           itemsHTML += `<li>${item.name} - $${item.price}</li>`;
//       });
//       itemsHTML += "</ul>";
//       selectedItemsDiv.innerHTML = itemsHTML;
//   } else {
//       selectedItemsDiv.innerHTML = "<p>No items selected.</p>";
//   }

//   // Update total price
//   totalSpan.innerText = total.toFixed(2);
// }

// // Function to clear the selection
// function clearSelection() {
//   const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
//   checkboxes.forEach(checkbox => checkbox.checked = false); // Uncheck all checkboxes
//   localStorage.removeItem("cartItems"); // Remove items from localStorage
//   updateBill(); // Update the bill to reflect no selected items
// }

// // Function to handle checkout (this is just a placeholder function)
// function checkout() {
//   alert("Checkout is not implemented yet.");
// }

// // Load items from localStorage when the page loads
// document.addEventListener("DOMContentLoaded", () => {
//   const savedItems = JSON.parse(localStorage.getItem("cartItems")) || [];

//   // Debugging log to check if saved items are loaded from localStorage
//   console.log('Saved Items from LocalStorage:', savedItems);

//   // Restore the checkbox state based on the saved items
//   const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
//   checkboxes.forEach(checkbox => {
//     const itemName = checkbox.nextElementSibling.innerText.split(' - ')[0];
//     const itemPrice = parseFloat(checkbox.dataset.price);

//     // If the item is in localStorage, check the box
//     if (savedItems.some(item => item.name === itemName && item.price === itemPrice)) {
//       checkbox.checked = true;
//     }
//   });

//   // Call displayBill with the items loaded from localStorage
//   displayBill(savedItems, savedItems.reduce((acc, item) => acc + item.price, 0));
// });
function updateBill() {
  const selectedItems = [];
  let total = 0;
  
  // Loop through all checkboxes and get selected items
  const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
  checkboxes.forEach(checkbox => {
      if (checkbox.checked) {
          const itemName = checkbox.nextElementSibling.innerText.split(' - ')[0]; // Extract item name
          const itemPrice = parseFloat(checkbox.dataset.price); // Get item price
          selectedItems.push({ name: itemName, price: itemPrice });
          total += itemPrice; // Update total
      }
  });

  // Debugging log to check if selected items are being collected correctly
  console.log('Selected Items:', selectedItems);  // Debugging line
  console.log('Total Price:', total);  // Debugging line

  // Save selected items in localStorage
  localStorage.setItem("cartItems", JSON.stringify(selectedItems));

  // Display selected items and total in the bill section
  displayBill(selectedItems, total);
}

// Function to display the selected items and total
function displayBill(selectedItems, total) {
  const selectedItemsDiv = document.getElementById('selectedItems');
  const totalSpan = document.getElementById('total');
  
  // Check if there are any selected items
  if (selectedItems.length > 0) {
      let itemsHTML = "<ul>";
      selectedItems.forEach(item => {
          itemsHTML += `<li>${item.name} - $${item.price}</li>`;
      });
      itemsHTML += "</ul>";
      selectedItemsDiv.innerHTML = itemsHTML;
  } else {
      selectedItemsDiv.innerHTML = "<p>No items selected.</p>";
  }

  // Update total price
  totalSpan.innerText = total.toFixed(2);
}

// Function to clear the selection
function clearSelection() {
  const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
  checkboxes.forEach(checkbox => checkbox.checked = false); // Uncheck all checkboxes
  localStorage.removeItem("cartItems"); // Remove items from localStorage
  updateBill(); // Update the bill to reflect no selected items
}

// Function to handle checkout (this will display the items on the screen)
// function checkout() {
//   // Get selected items from localStorage
//   const savedItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  
//   // Check if there are any saved items
//   if (savedItems.length > 0) {
//     // Create a container for the checkout display
//     const checkoutContainer = document.getElementById('checkoutItems');
    
//     // Clear any existing content in the checkout container
//     checkoutContainer.innerHTML = '';

//     // Add a header for checkout
//     checkoutContainer.innerHTML = '<h2>Checkout Items</h2>';
    
//     // Create a list of the items to display
//     let itemsHTML = "<ul>";
//     savedItems.forEach(item => {
//       itemsHTML += `<li>${item.name} - $${item.price}</li>`;
//     });
//     itemsHTML += "</ul>";
    
//     // Append the items list to the checkout container
//     checkoutContainer.innerHTML += itemsHTML;

//     // Optionally, you could also show the total price here
//     const total = savedItems.reduce((acc, item) => acc + item.price, 0);
//     checkoutContainer.innerHTML += `<p><strong>Total: $${total.toFixed(2)}</strong></p>`;
//   } else {
//     alert("No items in the cart to checkout.");
//   }
// }
function checkout() {
  // Get selected items from localStorage
  const savedItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  
  // Check if there are any saved items
  if (savedItems.length > 0) {
    // Redirect to bill.html where the items will be displayed
    window.location.href = 'bill.html'; // Redirect to the bill page
  } else {
    alert("No items in the cart to checkout.");
  }
}

// Load items from localStorage when the page loads
document.addEventListener("DOMContentLoaded", () => {
  const savedItems = JSON.parse(localStorage.getItem("cartItems")) || [];

  // Debugging log to check if saved items are loaded from localStorage
  console.log('Saved Items from LocalStorage:', savedItems);

  // Restore the checkbox state based on the saved items
  const checkboxes = document.querySelectorAll('.menu-item input[type="checkbox"]');
  checkboxes.forEach(checkbox => {
    const itemName = checkbox.nextElementSibling.innerText.split(' - ')[0];
    const itemPrice = parseFloat(checkbox.dataset.price);

    // If the item is in localStorage, check the box
    if (savedItems.some(item => item.name === itemName && item.price === itemPrice)) {
      checkbox.checked = true;
    }
  });

  // Call displayBill with the items loaded from localStorage
  displayBill(savedItems, savedItems.reduce((acc, item) => acc + item.price, 0));
});
